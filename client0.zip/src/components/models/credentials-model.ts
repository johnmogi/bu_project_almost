export class CredentialsModel {
  public constructor(public userName?: string, public password?: string) {}
}
export class ServerData {
  public constructor(public value?: string) {}
}
