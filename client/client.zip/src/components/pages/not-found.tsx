import React, { Component } from "react";

export class NotFound extends Component {
  public render() {
    return (
      <div className="404">
        <p>this is 404</p>
      </div>
    );
  }
}
