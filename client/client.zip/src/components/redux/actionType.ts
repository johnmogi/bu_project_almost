export enum ActionType {
  tracePort,
  Login,
  Logout,
  getVacations,
  updateVacations,
  vacsFollowed,
  vacsFollowers,
  addVacation,
  editVacation,
  removeVacation
}
