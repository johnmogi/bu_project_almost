TOASTS: <https://fkhadra.github.io/react-toastify/> <https://github.com/fkhadra/react-toastify#installation>

ICONS: (very- lightweight) <https://github.com/rhysd/react-component-bytesize-icons>
