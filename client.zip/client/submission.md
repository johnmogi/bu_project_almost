1.  create a simple guide for installation.
2. attach database  
3. clean password from dal
