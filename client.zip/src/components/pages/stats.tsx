import React, { Component } from "react";

export class StatsGraphs extends Component {
  public render() {
    return (
      <div className="stats">
        <p>this is stats</p>
      </div>
    );
  }
}
