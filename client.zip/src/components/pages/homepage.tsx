import React, { Component } from "react";
import Button from "react-bootstrap/Button";

export class Homepage extends Component {
  public render() {
    return (
      <div className="homepage">
        <h1>Stop the world!</h1>
        <p>
          We all want to get down... During these troubled times- Since all
          airports are shut down...
        </p>
        <p>
          Our to genius geeks at Travel Time Labs have invented the time portal
          machine...
        </p>

        <p>
          Make sure you register for an account so the time Shenanigens can
          start
        </p>
        <p>
          <Button variant="success">Sign up</Button>
          <Button variant="info">Sign in</Button>
        </p>
      </div>
    );
  }
}
