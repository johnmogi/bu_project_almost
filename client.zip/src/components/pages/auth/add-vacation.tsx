import React, { Component, ChangeEvent } from "react";

import { store } from "../../redux/store";
import { Action } from "../../redux/action";
import { ActionType } from "../../redux/actionType";
import { Unsubscribe } from "redux";

import { NewVacsModel, VacsModel } from "../../models/vacs-model";

import Table from "react-bootstrap/Table";
import Button from "react-bootstrap/Button";
import Form from "react-bootstrap/Form";

import { toast } from "react-toastify";

const PORT = process.env.PORT || 3010;

interface VacationsState {
  vacation: NewVacsModel;
}

export class AddVacation extends Component<any, VacationsState> {
  private unsubscribe: Unsubscribe;
  private fileInput: HTMLInputElement;

  public constructor(props: any) {
    super(props);
    this.state = {
      vacation: new NewVacsModel()
    };
    this.unsubscribe = store.subscribe(() => {
      //* fix up for better performance
      //  this.setState({ vacation: store.getState().vacation });
    });
  }
  public componentWillUnmount = () => {
    this.unsubscribe();
  };

  private setDestination = (args: ChangeEvent<HTMLInputElement>) => {
    const destination = args.target.value;
    // toast.info(destination);
    const vacation = { ...this.state.vacation };
    vacation.destination = destination;
    this.setState({ vacation });
  };
  private setDescription = (args: ChangeEvent<HTMLInputElement>) => {
    const description = args.target.value;
    // toast.info(description);
    const vacation = { ...this.state.vacation };
    vacation.description = description;
    this.setState({ vacation });
  };

  private setPicture = (args: ChangeEvent<HTMLInputElement>) => {
    // private setPicture = (event: any) => {

    const picFileName = args.target.files[0];
    console.log(picFileName);
    // console.log(event.target.result.toString());
    const vacation = { ...this.state.vacation };
    // vacation.picFileName = args.target.files[0];

    this.setState({ vacation });
  };

  private setStartDate = (args: ChangeEvent<HTMLInputElement>) => {
    const startDate = args.target.value;
    // toast.info(startDate);
    const vacation = { ...this.state.vacation };
    vacation.startDate = startDate;
    this.setState({ vacation });
  };
  private setEndDate = (args: ChangeEvent<HTMLInputElement>) => {
    const endDate = args.target.value;
    // toast.info(endDate);
    const vacation = { ...this.state.vacation };
    vacation.endDate = endDate;
    this.setState({ vacation });
  };
  private setPrice = (args: ChangeEvent<HTMLInputElement>) => {
    const price = args.target.value;
    // toast.info(price);
    const vacation = { ...this.state.vacation };
    vacation.price = price;
    this.setState({ vacation });
  };
  private validateForm = () => {
    if (this.state.vacation.picFileName == undefined) {
      toast.error("no pic");
      return;
    }
    toast("subauba");

    this.addVacForm();
  };
  private addVacForm = () => {
    const formData = new FormData();
    // formData.append("image", this.state.vacation.picFileName);
    formData.append("picFileName", this.state.vacation.picFileName);
    console.log(formData);

    const options = {
      method: "POST",
      body: formData
    };
    // try {
    //   fetch(`http://localhost:${PORT}/api/vacations`, options)
    //     .then(res => res.json())
    //     .then(vacation => this.setState({ vacation }))
    //     .catch(err => alert(err.message));
    // } catch (err) {
    //   alert(err.message);
    // }
  };

  private addVacForm2 = () => {
    const options = {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json"
      },
      body: JSON.stringify({ ...this.state.vacation })
    };
    console.log(JSON.stringify(options));
    fetch(`http://localhost:${PORT}/api/vacations`, options)
      .then(response => response.json())
      .then(vacation =>
        toast("vacation has been added." + JSON.stringify(vacation))
      )
      .catch(err => alert(err.message));
  };

  render() {
    return (
      <div className="add-vacation">
        <Table striped bordered hover responsive>
          <thead>
            <tr>
              <th>Destination</th>
              <th>Description</th>
              <th>Price</th>
              <th>StartDate</th>
              <th>EndDate</th>
              <th>PicFileName</th>

              <th>Add</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>
                <Form.Control
                  type="text"
                  placeholder="Vacation Name"
                  onChange={this.setDestination}
                />
              </td>
              <td>
                <Form.Group controlId="exampleForm.ControlTextarea1">
                  <Form.Control
                    as="textarea"
                    rows="1"
                    placeholder="Enter Vacation Description"
                    onChange={this.setDescription}
                  />
                </Form.Group>
              </td>
              <td>
                <Form.Control
                  type="text"
                  placeholder="Vacation Price"
                  onChange={this.setPrice}
                />
              </td>
              <td>
                <Form.Control
                  type="date"
                  placeholder="Start Date"
                  onChange={this.setStartDate}
                />
              </td>
              <td>
                <Form.Control
                  type="date"
                  placeholder="End Date"
                  onChange={this.setEndDate}
                />
              </td>
              <td>
                <input
                  accept="image/*"
                  className="setPicture"
                  id="outlined-button-file"
                  multiple
                  type="file"
                  name="setPicture"
                  onChange={this.setPicture}
                />
              </td>
              <td>
                <Button variant="outline-success" onClick={this.validateForm}>
                  Add Vacation
                </Button>
              </td>
            </tr>
          </tbody>
        </Table>
      </div>
    );
  }
}
