import React, { Component, ChangeEvent } from "react";

import { store } from "../../redux/store";
import { Action } from "../../redux/action";
import { ActionType } from "../../redux/actionType";
import { Unsubscribe } from "redux";

import { NewVacsModel, VacsModel } from "../../models/vacs-model";

import Table from "react-bootstrap/Table";
import Button from "react-bootstrap/Button";
import Form from "react-bootstrap/Form";

import { toast } from "react-toastify";

const PORT = process.env.PORT || 3010;

interface VacationsState {
  vacation: NewVacsModel;
}

export class AddVacation extends Component<any, VacationsState> {
  private unsubscribe: Unsubscribe;
  private fileInput: HTMLInputElement;

  public constructor(props: any) {
    super(props);
    this.state = {
      vacation: new NewVacsModel()
    };
    this.unsubscribe = store.subscribe(() => {
      //* fix up for better performance
      //  this.setState({ vacation: store.getState().vacation });
    });
  }
  public componentWillUnmount = () => {
    this.unsubscribe();
  };

  // public componentDidMount(): void {
  //   const vacation = { ...this.state.vacation };
  //   const date = new Date();
  //   date.setHours(0, 0, 0);
  //   vacation.startDate = date;
  //   // vacation.endDate = date;
  //   this.setState({ vacation });
  // }
  private setDestination = (args: ChangeEvent<HTMLInputElement>) => {
    const destination = args.target.value;
    // toast.info(destination);
    const vacation = { ...this.state.vacation };
    vacation.destination = destination;
    this.setState({ vacation });
  };
  private setDescription = (args: ChangeEvent<HTMLInputElement>) => {
    const description = args.target.value;
    // toast.info(description);
    const vacation = { ...this.state.vacation };
    vacation.description = description;
    this.setState({ vacation });
  };

  //? the form works, this is for validation later....
  // private setPicture = (args: ChangeEvent<HTMLInputElement>) => {
  //   const picFileName = args.target.value;
  //   // toast.info(description);
  //   const vacation = { ...this.state.vacation };
  //   vacation.picFileName = picFileName;
  //   this.setState({ vacation });
  // };

  private setPicture = (args: ChangeEvent<HTMLInputElement>) => {
    const picFileName = args.target.files[0];
    // console.log(event.target.result.toString());
    const vacation = { ...this.state.vacation };
    vacation.picFileName = picFileName;
    this.setState({ vacation });
  };

  private setPicture2 = async () => {
    const vacation = { ...this.state.vacation };
    return new Promise((resolve, reject) => {
      const formData = new FormData();
      formData.append("image", vacation.picFileName);

      const options = {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Accept: "application/json"
        },
        body: formData
      };
      console.log("this is from before the fetch" + options);
      fetch(`http://localhost:${PORT}/api/auth/file`, options)
        .then(res => res.json())
        .then(image => resolve(image))
        .catch(err => reject(err));
    });
  };

  private setStartDate = (args: ChangeEvent<HTMLInputElement>) => {
    const startDate = args.target.value;
    // toast.info(startDate);
    const vacation = { ...this.state.vacation };
    vacation.startDate = startDate;
    this.setState({ vacation });
  };
  private setEndDate = (args: ChangeEvent<HTMLInputElement>) => {
    const endDate = args.target.value;
    // toast.info(endDate);
    const vacation = { ...this.state.vacation };
    vacation.endDate = endDate;
    this.setState({ vacation });
  };
  private setPrice = (args: ChangeEvent<HTMLInputElement>) => {
    const price = args.target.value;
    // toast.info(price);
    const vacation = { ...this.state.vacation };
    vacation.price = price;
    this.setState({ vacation });
  };
  private validateForm = () => {
    if (this.state.vacation.picFileName == undefined) {
      toast.error("no pic");
    }
    toast("subauba");

    this.addVacForm();
  };
  private addVacForm = () => {
    const options = {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json"
      },
      body: JSON.stringify({ ...this.state.vacation })
    };
    console.log(JSON.stringify(options));
    fetch(`http://localhost:${PORT}/api/vacations`, options)
      .then(response => response.json())
      .then(vacation =>
        toast("vacation has been added." + JSON.stringify(vacation))
      )
      .catch(err => alert(err.message));
  };

  render() {
    return (
      <div className="add-vacation">
        <Table striped bordered hover responsive>
          <thead>
            <tr>
              <th>Destination</th>
              <th>Description</th>
              <th>Price</th>
              <th>StartDate</th>
              <th>EndDate</th>
              <th>PicFileName</th>

              <th>Add</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>
                <Form.Control
                  type="text"
                  placeholder="Vacation Name"
                  onChange={this.setDestination}
                />
              </td>
              <td>
                <Form.Group controlId="exampleForm.ControlTextarea1">
                  <Form.Control
                    as="textarea"
                    rows="1"
                    placeholder="Enter Vacation Description"
                    onChange={this.setDescription}
                  />
                </Form.Group>
              </td>
              <td>
                <Form.Control
                  type="text"
                  placeholder="Vacation Price"
                  onChange={this.setPrice}
                />
              </td>
              <td>
                <Form.Control
                  type="date"
                  placeholder="Start Date"
                  onChange={this.setStartDate}
                />
              </td>
              <td>
                <Form.Control
                  type="date"
                  placeholder="End Date"
                  onChange={this.setEndDate}
                />
              </td>
              <td>
                <input
                  type="file"
                  onChange={this.setPicture}
                  accept="image/*"
                  ref={fi => (this.fileInput = fi)}
                />
                <button type="button" onClick={() => this.fileInput.click()}>
                  Select Product Image
                </button>
                {/* 
                <Form.File id="custom-file" label="Custom file input" custom />
                <Form.Control
                  type="text"
                  placeholder="Vacation picture"
                  onChange={this.setPicture}
                  accept="image/*"
                  ref={fi => (this.fileInput = fi)}
                /> */}
              </td>
              <td>
                <Button variant="outline-success" onClick={this.validateForm}>
                  Add Vacation
                </Button>
              </td>
            </tr>
          </tbody>
        </Table>
      </div>
    );
  }
}
