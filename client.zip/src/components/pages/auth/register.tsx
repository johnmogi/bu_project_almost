import React, { Component } from "react";

export class Register extends Component {
  public render() {
    return (
      <div className="register">
        <p>this is register</p>
      </div>
    );
  }
}
