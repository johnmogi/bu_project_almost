export class CredentialsModel {
  public constructor(public userName?: string, public password?: string) {}
}
