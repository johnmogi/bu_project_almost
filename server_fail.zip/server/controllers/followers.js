const express = require("express");
const followLogic = require("../sql/followers");
const router = express.Router();

// http://localhost:3010/api/followers/
router.get("/", async (request, response) => {
  try {
    const followers = await followLogic.getAllFollowersAsync();
    response.json(followers);
  } catch (err) {
    response.status(500).send(err.message);
  }
});
router.get("/followed-vacs", async (request, response) => {
  try {
    const followed = await followLogic.getAllFollowedVacssAsync();
    response.json(followed);
  } catch (err) {
    response.status(500).send(err.message);
  }
});
router.post("/follow", async (request, response) => {
  try {
    const lookupUser = await followLogic.getFollowedVacs(request.body.userID);

    for (const i of lookupUser) {
      if (i.vacationID === request.body.vacationID) {
        // TODO reduce or prevent duplicates!
        // console.log(i.vacationID + " found");
        // console.log(lookupUser, i.vacationID);
        const toggleUser = await usersLogic.removeFollowedVac(
          request.body.userID,
          request.body.vacationID
        );
        response.sendStatus(204).send(toggleUser);
        // return response.status(403).send("user already follows this vacation");
      }
    }
    const addFollowToUser = await followLogic.addUserFollowAsync(request.body);
    response.status(200).send(addFollowToUser);
  } catch (error) {
    response.status(500).send(error);
  }
});

router.get("/follow/:id", async (request, response) => {
  try {
    const id = request.params.id;
    const vacs = await followLogic.getFollowedVacs(id);
    const vacsFollowedArr = [];
    // sending only followed vacs to reorder on client:
    for (let i = 0; i < vacs.length; i++) {
      vacsFollowedArr.push(vacs[i].vacationID);
    }

    response.json(vacs);
  } catch (error) {
    response.status(500).send(error);
  }
});
// remove followed vacation
router.delete("/delete/:userID/:vacationID", async (request, response) => {
  try {
    const userID = +request.params.userID;
    const vacationID = +request.params.vacationID;
    await followLogic.removeFollowedVac(userID, vacationID);
    response.sendStatus(204).send("deleted, also delete this message");
  } catch (error) {
    response.status(500).send(error);
  }
});

module.exports = router;
