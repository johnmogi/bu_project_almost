const express = require("express");
const usersLogic = require("../sql/users");
const router = express.Router();

// http://localhost:3010/api/auth/users
router.get("/users", async (request, response) => {
  try {
    const users = await usersLogic.getAllUsersAsync();
    response.json(users);
  } catch (err) {
    response.status(500).send(err.message);
  }
});
router.get("/users/:id", async (request, response) => {
  try {
    const id = +request.params.id;
    const user = await usersLogic.getOneUserAsync(id);
    response.json(user);
  } catch (err) {
    response.status(500).send(err.message);
  }
});

router.post("/register", async (request, response) => {
  try {
    const user = request.body;
    const newUser = await usersLogic.addUserAsync(user);
    if (newUser === 0) {
      throw "User name already exists";
    }
    if (newUser === 1) {
      throw "Something is missing";
    }
    response.status(201).json(newUser);
  } catch (error) {
    response.status(500).send(error);
  }
});
router.post("/login", async (request, response) => {
  try {
    const credentials = request.body;
    // console.log(credentials);
    if (!credentials.userName || !credentials.password) {
      response.status(401).send("Missing username or password, Try Again");
      return;
    }
    const user = await usersLogic.getOneUserAsync(credentials);
    if (user === 0) {
      response.status(401).send("Incorrect username or password, Try Again");
      return;
    }
    if (user[0].isAdmin == 1) {
      request.session.isLoggedIn = true;
      request.session.isAdmin = true;
      request.session.role = "Admin";
    } else {
      request.session.isLoggedIn = true;
      request.session.isAdmin = false;
      request.session.role = "User";
    }
    response.status(201).send(user[0]);
  } catch (err) {
    response.status(500).send(err);
  }
});

router.post("/logout", (request, response) => {
  request.session.destroy();
  response.send({ value: "Bye Bye" });
});

module.exports = router;
