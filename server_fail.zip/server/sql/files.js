const dal = require("../database/dal");

const fs = require("fs");
const express = require("express");
const fileUpload = require("express-fileupload");
const cors = require("cors");
const uuid = require("uuid");
const server = express();

if (!fs.existsSync(__dirname + "\\uploads")) {
  // Must create "/uploads" folder if not exist.
  fs.mkdirSync(__dirname + "\\uploads");
}

server.use(cors());
server.use(express.json());
server.use(fileUpload());
let nextID = 1;

server.post("/api/products", (request, response) => {
  try {
    const product = request.body;
    product.id = nextID++;
    console.log(product);
    const file = request.files.image;
    const extension = file.name.substr(file.name.lastIndexOf(".")); // E.g: ".jpg"
    file.mv("./uploads/" + uuid.v4() + extension); // E.g: "C:\my-project\uploads\204b3caf-9e37-4600-9537-9f7b4cbb181b.jpg"
    response.json(product);
  } catch (err) {
    response.status(500).send(err.message);
  }
});

server.get("/api/uploads/:imgName", (request, response) => {
  response.sendFile(__dirname + "\\uploads\\" + request.params.imgName);
});
