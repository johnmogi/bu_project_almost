const dal = require("../database/dal");

async function addUserFollowAsync(user) {
  //take values and see if user is following the vacation:

  const sql = `INSERT INTO followers (userID, vacationID) VALUES (${user.userID}, ${user.vacationID})`;
  const vac = await dal.executeAsync(sql);
  return vac;
}

async function getAllFollowersAsync() {
  const sql = `SELECT * FROM followers`;
  const followers = await dal.executeAsync(sql);
  return followers;
}
async function getFollowedVacs(id) {
  const sql = `SELECT * FROM followers 
    where userID = ${id}`;
  const vacs = await dal.executeAsync(sql);
  return vacs;
}
async function getAllFollowedVacssAsync() {
  const sql = `SELECT * FROM followers WHERE vacationID > 0`;
  const followed = await dal.executeAsync(sql);
  return followed;
}
async function removeFollowedVac(id, vac) {
  const sql = `DELETE FROM followers WHERE userID = ${id} and vacationID = ${vac}`;
  // return sql;
}

module.exports = {
  addUserFollowAsync,
  getAllFollowersAsync,
  getFollowedVacs,
  getAllFollowedVacssAsync,
  removeFollowedVac
};
