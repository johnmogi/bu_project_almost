const express = require("express");
const expressSession = require("express-session");
const cors = require("cors");

const { port } = require("./config");
const { origin } = require("./config");

const server = express();

const authController = require("./controllers/users");
const vacsController = require("./controllers/vacations");
const followController = require("./controllers/followers");
// const filesController = require("./controllers/files");

server.use(cors({ origin: `http://localhost:${origin}`, credentials: true }));
server.use(cors());
server.use(
  expressSession({
    name: "VacationCookie",
    secret: "go-time-travel",
    resave: true,
    saveUninitialized: false
  })
);

server.use("/api", vacsController);
server.use("/api/followers", followController);
server.use("/api/auth", authController);
// server.use("/api/admin/file", filesController);

server.listen(port, () =>
  console.log(`Server Vacations running on port http://localhost:${port}`)
);
